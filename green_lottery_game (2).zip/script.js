const ticketContainer = document.getElementById("ticket-container");

function createTickets() {
  ticketContainer.innerHTML = "";
  for (let i = 1; i <= 6; i++) {
    let ticket = document.createElement("div");
    ticket.classList.add("ticket");
    ticket.textContent = "Ticket " + i;
    ticket.onclick = () => checkWin(i);
    ticketContainer.appendChild(ticket);
  }
}

function checkWin(ticketNumber) {
  let winNumber = Math.floor(Math.random() * 6) + 1;
  if (ticketNumber === winNumber) {
    alert("🎉 बधाई हो! आप जीत गए Ticket " + ticketNumber + " से!");
  } else {
    alert("😢 माफ़ कीजिये, यह टिकट नहीं जीता। कोशिश जारी रखो!");
  }
}

function playAgain() {
  createTickets();
}

createTickets();